# NUNES - Start-to-End Runbook

## DAY 1 - Make the base run

1. Install Docker Desktop.
2. Confirm Docker is running.
3. Confirm Ollama works.
4. Extract this project.
5. Copy `.env.example` to `.env`.
6. Set passwords.
7. Double-click `START_NUNES_LOCAL.bat`.
8. Open `http://localhost:8000/health`.
9. Open `http://localhost:5678`.
10. Complete the first API test from README.

Do not continue until all three are healthy:
- PostgreSQL
- FastAPI
- n8n

## DAY 2 - Import first real sample

Export only 50-100 products from ONE IndiaMART account first.

Map fields:
- product name
- model
- brand
- category
- description
- price
- source URL/id

Import them into `raw_product`.

Promote/match them into Product Master.

Review duplicate behavior before importing thousands of records.

## DAY 3 - Local AI classification

Classify the same 50-100 products.

Manually review:
- B2B
- B2C
- B2B+B2C

Correct bad classifications.

Only then batch-classify more.

## DAY 4 - Content generation

Select 10 verified products.

Generate:
- LinkedIn
- Facebook
- Instagram
- WhatsApp

Review:
- Does it invent specs?
- Does it repeat text?
- Is brand/account voice appropriate?

Do not publish automatically yet.

## WEEK 2 - Expand Product Master

Import remaining IndiaMART accounts and websites.

Priority:
1. Exact model matching
2. SF/product code matching
3. Brand + model
4. Normalized title
5. Local embeddings
6. AI only for uncertain cases
7. Human review

## WEEK 3 - Build review dashboard

Required screens:
- Product Master
- Raw listings
- Duplicate review
- Classification review
- Content approval
- Lead inbox
- Analytics

## WEEK 4 - Marketing pilot

Choose 100 high-priority products.

Daily:
- 3-6 products
- one master brief/product
- account/channel variants
- staff approval
- manual/native scheduling

Measure:
- views
- clicks
- WhatsApp enquiries
- IndiaMART enquiries
- quotes
- orders

## MONTH 2 - Lead integration

Connect enquiries to CRM.

Flow:

Lead
→ extract requirement
→ match product
→ assign staff
→ quote/catalog
→ follow-up
→ won/lost

## MONTH 3 - Selective automation

Only after proving accuracy:

- auto-schedule low-risk posts
- add official social APIs
- add WhatsApp Business API for qualified leads
- add automated analytics
- add management weekly report

Keep:
- technical changes
- prices
- quotations
- master merges
- high-value product claims

under human approval.
