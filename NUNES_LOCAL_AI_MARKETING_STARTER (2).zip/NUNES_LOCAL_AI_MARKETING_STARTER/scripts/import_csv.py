import csv, json, sys, requests

API = "http://localhost:8000"
if len(sys.argv) < 3:
    print("Usage: python import_csv.py <SOURCE_CODE> <file.csv>")
    sys.exit(1)

source = sys.argv[1]
file_path = sys.argv[2]

with open(file_path, newline="", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f)
    count = 0
    for row in reader:
        payload = {
            "source_code": source,
            "source_product_id": row.get("source_product_id") or row.get("id"),
            "source_url": row.get("source_url") or row.get("url"),
            "product_name": row.get("product_name") or row.get("name") or row.get("title"),
            "model": row.get("model"),
            "brand": row.get("brand"),
            "category": row.get("category"),
            "description": row.get("description"),
            "specs": {},
            "price": float(row["price"]) if row.get("price") else None,
        }
        if not payload["product_name"]:
            continue
        r = requests.post(API + "/raw-product", json=payload, timeout=60)
        r.raise_for_status()
        count += 1
print(f"Imported {count} records.")
