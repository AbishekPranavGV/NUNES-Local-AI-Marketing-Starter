@echo off
setlocal
cd /d "%~dp0"
if not exist backups mkdir backups
for /f "tokens=1-4 delims=/ " %%a in ('date /t') do set d=%%d-%%b-%%c
docker compose exec -T postgres pg_dump -U nunes nunes_ai > "backups\nunes_ai_%date:~-4%%date:~4,2%%date:~7,2%.sql"
echo Backup complete.
pause
