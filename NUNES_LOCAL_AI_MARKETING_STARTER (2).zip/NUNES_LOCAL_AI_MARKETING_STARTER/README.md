# NUNES Local AI Marketing Platform - Starter Base

This project is the minimum working local foundation for:

- Product ingestion
- Raw staging
- Product Master
- Exact-model duplicate matching
- Local AI B2B/B2C classification
- Local AI marketing draft generation
- n8n automation
- PostgreSQL storage
- Future CRM / social publishing integrations

## 1. What you need

Windows 10/11 or Windows Server with:

- Docker Desktop
- Ollama
- Git (recommended)
- At least 16 GB RAM; 32 GB+ is better for larger local models
- Existing Ollama model such as `qwen3:4b`

## 2. Prepare Ollama

Open PowerShell:

```powershell
ollama list
```

Make sure the model in `.env` exists.

Example:

```powershell
ollama pull qwen3:4b
```

Test:

```powershell
ollama run qwen3:4b
```

Exit the model chat after confirming it works.

## 3. Configure the project

Copy:

```text
.env.example
```

to:

```text
.env
```

Change at minimum:

```env
POSTGRES_PASSWORD=YOUR_STRONG_PASSWORD
N8N_BASIC_AUTH_PASSWORD=YOUR_STRONG_PASSWORD
```

Also replace:

```text
N8N_ENCRYPTION_KEY
```

in `docker-compose.yml` with a long random value before production use.

## 4. Start everything

Double-click:

```text
START_NUNES_LOCAL.bat
```

or run:

```powershell
docker compose up -d --build
```

Open:

- API: http://localhost:8000/docs
- API health: http://localhost:8000/health
- n8n: http://localhost:5678

## 5. First functional test

In the FastAPI Swagger page:

1. Open `POST /raw-product`
2. Click **Try it out**
3. Use:

```json
{
  "source_code": "GLOBE",
  "source_product_id": "TEST-001",
  "source_url": "",
  "product_name": "Portable Surface Roughness Tester",
  "model": "XYZ-100",
  "brand": "DemoBrand",
  "category": "Surface Testing",
  "description": "Demo product for system test",
  "specs": {},
  "price": null
}
```

Copy the returned `raw_product_id`.

Then run:

`POST /promote-raw/{raw_id}`

This creates or matches a Product Master record.

Then run:

`POST /classify`

with:

```json
{
  "product_master_id": 1
}
```

This asks your LOCAL Ollama model to classify B2B/B2C/B2B+B2C.

Then run:

`POST /content`

with:

```json
{
  "product_master_id": 1,
  "brand_account": "Globe Instrumentation",
  "channel": "LinkedIn"
}
```

The draft is stored in PostgreSQL with status `DRAFT`.

## 6. Import real product CSV data

Prepare a CSV with columns such as:

```text
source_product_id
source_url
product_name
model
brand
category
description
price
```

Then from the project folder:

```powershell
python .\scripts\import_csv.py IM1 .\data\import\account1.csv
```

Valid source codes already seeded:

- GLOBE
- THEINST
- ISMART
- IM1
- IM2
- IM3

## 7. Recommended build order

### Phase A - Foundation
1. Server/PC
2. Docker
3. PostgreSQL
4. n8n
5. Ollama
6. API
7. Backups

### Phase B - Product Master
1. Import Account 1
2. Import Account 2
3. Import Account 3
4. Import 3 websites
5. Normalize
6. Exact model matching
7. Duplicate review queue
8. Assign Master Product IDs

### Phase C - Intelligence
1. B2B/B2C
2. Category
3. Product family
4. Buyer type
5. Industry
6. Data Quality Score
7. SEO readiness

### Phase D - Content
1. Product factual brief
2. LinkedIn draft
3. Facebook draft
4. Instagram draft
5. WhatsApp draft
6. Website draft
7. IndiaMART draft
8. Approval

### Phase E - Publishing
Keep external publishing disabled initially.

Start with:
1. Generate content locally
2. Review locally
3. Export/copy approved content
4. Publish manually/native scheduler

After 30-60 days, connect official APIs selectively.

### Phase F - Leads
1. Import/capture enquiry
2. Requirement extraction
3. Product Master match
4. CRM handoff
5. Catalog/quote
6. Follow-up
7. Won/Lost analytics

## 8. First n8n workflow

Create:

```text
Schedule 07:00
↓
HTTP GET /products?limit=5
↓
Loop Products
↓
POST /classify when classification missing
↓
POST /content for required channels
↓
Leave as DRAFT
↓
Send approval summary
```

Do NOT auto-publish in the first version.

## 9. Production rules

- Do not invent product specifications.
- Do not auto-merge uncertain products.
- Do not delete raw source records.
- Do not auto-send customer messages initially.
- Do not auto-publish technical/high-value products initially.
- Back up PostgreSQL daily.
- Keep the platform LAN-only until authentication/security is reviewed.

## 10. What to build next

After this base works, add:

- Review dashboard
- Duplicate candidate screen
- CSV/XLSX importer
- Google Drive indexer
- Product image library
- Data Quality Score calculation
- SEO generator
- Social content calendar
- Lead API
- CRM integration
- Analytics dashboard
- Optional official social publishing connectors
