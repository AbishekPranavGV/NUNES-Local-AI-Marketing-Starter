import os, requests

BASE = os.getenv("OLLAMA_BASE_URL", "http://host.docker.internal:11434")
MODEL = os.getenv("OLLAMA_MODEL", "qwen3:4b")

def generate(prompt: str) -> str:
    r = requests.post(
        f"{BASE}/api/generate",
        json={"model": MODEL, "prompt": prompt, "stream": False},
        timeout=180,
    )
    r.raise_for_status()
    return r.json().get("response", "").strip()
