import re

def normalize_product_name(name: str) -> str:
    text = (name or "").strip().lower()
    text = re.sub(r"[^a-z0-9+./% -]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def normalize_model(model: str | None) -> str | None:
    if not model:
        return None
    text = re.sub(r"\s+", "", model.upper().strip())
    return text or None
