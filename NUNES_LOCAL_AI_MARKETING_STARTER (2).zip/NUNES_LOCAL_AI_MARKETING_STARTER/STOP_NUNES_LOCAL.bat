@echo off
cd /d "%~dp0"
docker compose down
echo NUNES Local services stopped.
pause
