
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE IF NOT EXISTS source_registry (
    id BIGSERIAL PRIMARY KEY,
    source_code TEXT UNIQUE NOT NULL,
    source_name TEXT NOT NULL,
    source_type TEXT NOT NULL,
    base_url TEXT,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS raw_product (
    id BIGSERIAL PRIMARY KEY,
    source_id BIGINT REFERENCES source_registry(id),
    source_product_id TEXT,
    source_url TEXT,
    original_name TEXT NOT NULL,
    original_model TEXT,
    original_brand TEXT,
    original_category TEXT,
    original_description TEXT,
    original_specs JSONB DEFAULT '{}'::jsonb,
    price NUMERIC(14,2),
    price_currency TEXT DEFAULT 'INR',
    imported_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS product_master (
    id BIGSERIAL PRIMARY KEY,
    master_code TEXT UNIQUE,
    product_name TEXT NOT NULL,
    normalized_name TEXT NOT NULL,
    product_family TEXT,
    category TEXT,
    subcategory TEXT,
    brand TEXT,
    manufacturer TEXT,
    model TEXT,
    market_type TEXT CHECK (market_type IN ('B2B','B2C','B2B+B2C') OR market_type IS NULL),
    classification_confidence NUMERIC(5,2),
    classification_reason TEXT,
    verification_status TEXT DEFAULT 'REVIEW',
    data_quality_score NUMERIC(5,2) DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS product_source_listing (
    id BIGSERIAL PRIMARY KEY,
    product_master_id BIGINT REFERENCES product_master(id),
    raw_product_id BIGINT REFERENCES raw_product(id),
    match_status TEXT DEFAULT 'UNREVIEWED',
    match_confidence NUMERIC(5,2),
    match_reason TEXT,
    UNIQUE(raw_product_id)
);

CREATE TABLE IF NOT EXISTS marketing_content (
    id BIGSERIAL PRIMARY KEY,
    product_master_id BIGINT REFERENCES product_master(id),
    brand_account TEXT NOT NULL,
    channel TEXT NOT NULL,
    content_type TEXT DEFAULT 'POST',
    content_text TEXT NOT NULL,
    content_hash TEXT,
    status TEXT DEFAULT 'DRAFT',
    approved_by TEXT,
    approved_at TIMESTAMPTZ,
    scheduled_at TIMESTAMPTZ,
    published_at TIMESTAMPTZ,
    external_post_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS lead (
    id BIGSERIAL PRIMARY KEY,
    source TEXT,
    customer_name TEXT,
    company TEXT,
    phone TEXT,
    email TEXT,
    city TEXT,
    state TEXT,
    country TEXT,
    requirement TEXT,
    requested_product TEXT,
    requested_model TEXT,
    quantity TEXT,
    urgency TEXT,
    market_type TEXT,
    product_master_id BIGINT REFERENCES product_master(id),
    status TEXT DEFAULT 'NEW',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    entity_type TEXT,
    entity_id TEXT,
    action TEXT NOT NULL,
    details JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO source_registry (source_code, source_name, source_type, base_url)
VALUES
('GLOBE','Globe Instrumentation','WEBSITE','https://www.globeinstrumentation.com/'),
('THEINST','The Instrumentation','WEBSITE','https://www.theinstrumentation.com/'),
('ISMART','Instruments Mart','WEBSITE','https://www.instrumentsmart.com/'),
('IM1','IndiaMART Account 1','MARKETPLACE',NULL),
('IM2','IndiaMART Account 2','MARKETPLACE',NULL),
('IM3','IndiaMART Account 3','MARKETPLACE',NULL)
ON CONFLICT (source_code) DO NOTHING;
