import os, json, hashlib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import psycopg

from services.normalizer import normalize_product_name, normalize_model
from services.ollama import generate

app = FastAPI(title="NUNES Local Product Intelligence API", version="0.1.0")

def conn():
    return psycopg.connect(
        host=os.getenv("POSTGRES_HOST", "postgres"),
        port=os.getenv("POSTGRES_PORT", "5432"),
        dbname=os.getenv("POSTGRES_DB", "nunes_ai"),
        user=os.getenv("POSTGRES_USER", "nunes"),
        password=os.getenv("POSTGRES_PASSWORD"),
    )

class RawProductIn(BaseModel):
    source_code: str
    source_product_id: str | None = None
    source_url: str | None = None
    product_name: str
    model: str | None = None
    brand: str | None = None
    category: str | None = None
    description: str | None = None
    specs: dict = {}
    price: float | None = None

class ClassifyIn(BaseModel):
    product_master_id: int

class ContentIn(BaseModel):
    product_master_id: int
    brand_account: str
    channel: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/raw-product")
def add_raw_product(item: RawProductIn):
    with conn() as c, c.cursor() as cur:
        cur.execute("SELECT id FROM source_registry WHERE source_code=%s", (item.source_code,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(400, "Unknown source_code")
        cur.execute(
            '''INSERT INTO raw_product
            (source_id, source_product_id, source_url, original_name, original_model,
             original_brand, original_category, original_description, original_specs, price)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            RETURNING id''',
            (row[0], item.source_product_id, item.source_url, item.product_name,
             item.model, item.brand, item.category, item.description,
             json.dumps(item.specs), item.price)
        )
        raw_id = cur.fetchone()[0]
        c.commit()
    return {"raw_product_id": raw_id}

@app.post("/promote-raw/{raw_id}")
def promote_raw(raw_id: int):
    with conn() as c, c.cursor() as cur:
        cur.execute(
            '''SELECT original_name, original_model, original_brand, original_category
               FROM raw_product WHERE id=%s''',
            (raw_id,)
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Raw product not found")
        name, model, brand, category = row
        normalized = normalize_product_name(name)
        model_n = normalize_model(model)

        # Exact model first
        if model_n:
            cur.execute(
                "SELECT id, master_code FROM product_master WHERE upper(replace(coalesce(model,''),' ',''))=%s LIMIT 1",
                (model_n,)
            )
            found = cur.fetchone()
            if found:
                cur.execute(
                    '''INSERT INTO product_source_listing
                       (product_master_id, raw_product_id, match_status, match_confidence, match_reason)
                       VALUES (%s,%s,'PROBABLE MATCH',95,'Exact normalized model match')
                       ON CONFLICT (raw_product_id) DO NOTHING''',
                    (found[0], raw_id)
                )
                c.commit()
                return {"matched_existing": True, "product_master_id": found[0], "master_code": found[1]}

        cur.execute(
            '''INSERT INTO product_master
               (product_name, normalized_name, category, brand, model)
               VALUES (%s,%s,%s,%s,%s)
               RETURNING id''',
            (name, normalized, category, brand, model_n)
        )
        pid = cur.fetchone()[0]
        master_code = f"NUNES-MP-{pid:06d}"
        cur.execute("UPDATE product_master SET master_code=%s WHERE id=%s", (master_code,pid))
        cur.execute(
            '''INSERT INTO product_source_listing
               (product_master_id, raw_product_id, match_status, match_confidence, match_reason)
               VALUES (%s,%s,'NEW MASTER',100,'No exact model match; created reviewable master')''',
            (pid, raw_id)
        )
        c.commit()
    return {"matched_existing": False, "product_master_id": pid, "master_code": master_code}

@app.post("/classify")
def classify(item: ClassifyIn):
    with conn() as c, c.cursor() as cur:
        cur.execute(
            '''SELECT product_name, model, category, brand
               FROM product_master WHERE id=%s''',
            (item.product_master_id,)
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Product not found")
        product_name, model, category, brand = row

    prompt = f'''
Classify the following product for an industrial instrumentation seller.
Return EXACTLY 3 lines:
CLASSIFICATION: B2B or B2C or B2B+B2C
CONFIDENCE: integer 0-100
REASON: one concise sentence

Product: {product_name}
Model: {model}
Category: {category}
Brand: {brand}

Use typical buyer, technical complexity, procurement method, application and consumer usability.
Do not invent specifications.
'''
    answer = generate(prompt)
    classification = None
    confidence = None
    reason = answer
    for line in answer.splitlines():
        if line.upper().startswith("CLASSIFICATION:"):
            classification = line.split(":",1)[1].strip()
        elif line.upper().startswith("CONFIDENCE:"):
            try: confidence = float(line.split(":",1)[1].strip())
            except: pass
        elif line.upper().startswith("REASON:"):
            reason = line.split(":",1)[1].strip()

    valid = {"B2B","B2C","B2B+B2C"}
    if classification not in valid:
        raise HTTPException(500, f"Unexpected local AI response: {answer}")

    with conn() as c, c.cursor() as cur:
        cur.execute(
            '''UPDATE product_master
               SET market_type=%s, classification_confidence=%s,
                   classification_reason=%s, updated_at=NOW()
               WHERE id=%s''',
            (classification, confidence, reason, item.product_master_id)
        )
        c.commit()

    return {"classification": classification, "confidence": confidence, "reason": reason}

@app.post("/content")
def create_content(item: ContentIn):
    with conn() as c, c.cursor() as cur:
        cur.execute(
            '''SELECT product_name, model, category, brand, market_type, verification_status
               FROM product_master WHERE id=%s''',
            (item.product_master_id,)
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Product not found")
        product_name, model, category, brand, market_type, verification_status = row

    prompt = f'''
You create marketing drafts for Nunes Instruments.
Use ONLY the facts below. Do not invent technical specifications, price, certifications,
stock, delivery or warranty.

Product: {product_name}
Model: {model}
Category: {category}
Brand: {brand}
Market type: {market_type}
Brand account: {item.brand_account}
Channel: {item.channel}

Write a concise professional {item.channel} post with:
1) hook
2) application/use case
3) buyer relevance
4) enquiry CTA
Do not state unverified specifications.
'''
    text = generate(prompt)
    content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()

    with conn() as c, c.cursor() as cur:
        cur.execute(
            '''INSERT INTO marketing_content
               (product_master_id, brand_account, channel, content_text, content_hash, status)
               VALUES (%s,%s,%s,%s,%s,'DRAFT')
               RETURNING id''',
            (item.product_master_id, item.brand_account, item.channel, text, content_hash)
        )
        cid = cur.fetchone()[0]
        c.commit()

    return {"content_id": cid, "status": "DRAFT", "content": text}

@app.get("/products")
def products(limit: int = 100):
    with conn() as c, c.cursor() as cur:
        cur.execute(
            '''SELECT id, master_code, product_name, model, category, market_type,
                      verification_status, data_quality_score
               FROM product_master
               ORDER BY id DESC
               LIMIT %s''',
            (min(limit,500),)
        )
        rows = cur.fetchall()
    return [
        {
            "id": r[0], "master_code": r[1], "product_name": r[2], "model": r[3],
            "category": r[4], "market_type": r[5], "verification_status": r[6],
            "data_quality_score": float(r[7] or 0)
        }
        for r in rows
    ]
