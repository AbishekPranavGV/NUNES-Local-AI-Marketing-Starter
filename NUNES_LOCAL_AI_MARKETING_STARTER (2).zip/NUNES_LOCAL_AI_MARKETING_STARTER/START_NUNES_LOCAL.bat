@echo off
setlocal
cd /d "%~dp0"

if not exist ".env" (
  echo.
  echo [ERROR] .env not found.
  echo Copy .env.example to .env and set strong passwords first.
  echo.
  pause
  exit /b 1
)

echo Starting NUNES Local AI Marketing Platform...
docker compose up -d --build
echo.
echo API health: http://localhost:8000/health
echo API docs  : http://localhost:8000/docs
echo n8n       : http://localhost:5678
echo.
pause
